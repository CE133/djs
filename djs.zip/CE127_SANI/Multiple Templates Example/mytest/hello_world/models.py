from django.db import models

# Create your models here.

class Student(models.Model):
	student_name = models.CharField('Student Name',max_length=100)
	student_dob = models.DateTimeField('StudentDOB')
