from django.apps import AppConfig


class DbtestappConfig(AppConfig):
    name = 'dbtestapp'
