from django.conf.urls import url
from viewdemoapp import views

urlpatterns = [

	url(r'^index/$', views.HomePageView.as_view()),
	url(r'^aboutme/$',views.aboutme),
	url(r'^contactme/$',views.contactme),
]
