from django.apps import AppConfig


class ViewdemoappConfig(AppConfig):
    name = 'viewdemoapp'
