from django.shortcuts import render,render_to_response

# Create your views here.
'''
from django.http import HttpResponse, HttpResponseRedirect
from django.template.context_processors import csrf
from django.views import generic
'''
from django.views.generic import TemplateView


class HomePageView(TemplateView):
    def get(self, request, **kwargs):
        return render(request,'index.html', context=None)

def aboutme(request):
	return render(request,'AboutMe.html',context=None)
	
def contactme(request):
	return render(request,'ContactMe.html',context=None)
